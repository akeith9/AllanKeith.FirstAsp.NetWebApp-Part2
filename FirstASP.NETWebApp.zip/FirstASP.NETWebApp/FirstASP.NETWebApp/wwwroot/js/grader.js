﻿//submit button 
$("#submit").click( function () {
        //variables to hold letter grade and percentage
        var grade;
    var letter;
    grade = (parseInt($("#assignments").val()) * .5) +
        (parseInt($("#group").val()) * .1) +
        (parseInt($("#quizzes").val()) * .1) +
        (parseInt($("#exams").val()) * .2) +
        (parseInt($("#intex").val()) * .1);
        //case statement to assign value to grade
        switch (true) {
            case (grade >= 94):
                letter = "A";
                break;
            case (grade < 94 && grade >= 90):
                letter = "A-";
                break;
            case (grade < 90 && grade >= 87):
                letter = "B+";
                break;
            case (grade < 87 && grade >= 84):
                letter = "B";
                break;
            case (grade < 84 && grade >= 80):
                letter = "B-";
                break;
            case (grade < 80 && grade >= 77):
                letter = "C+";
                break;
            case (grade < 77 && grade >= 74):
                letter = "C";
                break;
            case (grade < 74 && grade >= 70):
                letter = "C-";
                break;
            case (grade < 70 && grade >= 67):
                letter = "D+";
                break;
            case (grade < 67 && grade >= 64):
                letter = "D";
                break;
            case (grade < 64 && grade >= 60):
                letter = "D-";
                break;
            default:
                letter = "E";
        }
        //alert message with grade
        alert("Your overall score is " + grade + " and your letter grade is " + letter);
    })

//shortcut for jquery is $. and $ also acts as document.getElementById

