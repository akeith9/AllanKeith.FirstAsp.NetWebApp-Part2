﻿using FirstASP.NETWebApp.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FirstASP.NETWebApp.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            //throw new IndexOutOfRangeException(); //gives an error page with good info

            return View();
        }

        //gets the grader view
        [HttpGet("Grader")]
        public IActionResult Grader()
        {
            return View();
        }

        //posts grader view
        [HttpPost("Grader")]
        public IActionResult Grader(GraderModel model)
        {
            return View();
        }
    }
}
