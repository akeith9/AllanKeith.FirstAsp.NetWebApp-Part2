﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FirstASP.NETWebApp.Models
{
    public class GraderModel
    {
        //grader model with limits on numbers that can be inputted
        [Range(0, 100,
        ErrorMessage = "Value for {0} must be between {1} and {2}.")]
        public int assignments { get; set; }
        [Range(0, 100,
        ErrorMessage = "Value for {0} must be between {1} and {2}.")]
        public int group { get; set; }
        [Range(0, 100,
        ErrorMessage = "Value for {0} must be between {1} and {2}.")]
        public int quizzes { get; set; }
        [Range(0, 100,
        ErrorMessage = "Value for {0} must be between {1} and {2}.")]
        public int exams { get; set; }
        [Range(0, 100,
        ErrorMessage = "Value for {0} must be between {1} and {2}.")]
        public int intex { get; set; }




        /*public String from;

        public String getFrom ()
        {
            return from;
        }

        public void setFrom (String x)
        {
            from = x;
        }*/
    }
}
