using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FirstASP.NETWebApp
{
    public class Startup //start
    {
        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllersWithViews();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsEnvironment("Development"))
            {
                app.UseDeveloperExceptionPage(); //handles errors or bugs
            }
            else
            {
                //error page for the user
            }

            app.UseNodeModules(); //handles node and packages
            //app.UseDefaultFiles(); //default files must come before static files, order matters
            app.UseStaticFiles();

            app.UseRouting(); //creates a path for the controller

            app.UseEndpoints(cfg => //determines finally what view we are going to use
            {
                cfg.MapControllerRoute("Default",
                    "{controller}/{action}/{id?}", 
                    new { controller = "Home", action = "Index"});
            }
            );
        }
    }
}
